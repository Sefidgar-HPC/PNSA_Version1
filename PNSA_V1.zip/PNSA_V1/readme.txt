				 PNSA (Parallel Nodal Sparse Assembler) Version 1
				==================================================
---------------
| 1-Authors:  |
---------------
Seyed Mohammad Hassan Sefidgar (Master of Strutural Engineering):
hasan.mamad1370.mh@gmail.com
Ali Rahmani Firoozjaee (PhD of Computational Mechanics): 
rahmani.firoozjaee@gmail.com 
rahmani@nit.ac.ir

--------------------
| 2-introduction:  | 
--------------------
PNSA contains a set of subroutines to Assemble local stiffness
matrices to CRS (compressed sparse row) format. PNSA supports two
computer programming languages: C (for zero-based index) and Fortran for
(one-based index). Sparse assembling is required to deal with HPC technique.
PNSA captures some basic information of problem domains and implements
assembling on nodes then expand row indexes to each DOF. 

------------------------------
| 3-Minimum system required:  | 
------------------------------
3-1-Installing gcc version 6.5.0:
sudo apt-get update 
sudo apt-get install build-essential software-properties-common -y 
sudo add-apt-repository ppa:ubuntu-toolchain-r/test -y 
sudo apt-get update 
sudo apt-get install gcc-6 g++-6 -y 
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-6 60 --slave /usr/bin/g++ g++ /usr/bin/g++-6 
gcc -v

3-2-installing gfortran version 5.4.0
sudo apt-get install gfortarn

------------------------------
| 4-How to install and run the package:  |
------------------------------
cd PNSA
cd C or cd Fortran
sudo chmod 777 makefile
./makefile

-----------------------------------------------------------
| 5-HPC Setting and environmental variables for big data:  |
-----------------------------------------------------------
To increase the stack size of the main thread: ulimite -s unlimited
To increase the stack size of helper thread: export OMP_STACKSIZE= "Your required memory"
To change default threads: export OMP_NUM_THREADS = Your Intended Number of threads
To set the path for MPI: export PATH=/your MPI directory/:$PATH

----------------------
| 6-Release versions |
----------------------
August 1,  2021  Version 1.0



