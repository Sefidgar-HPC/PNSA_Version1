void preproc1 (int nn,int ns,int ivdim,int maxdim,int *nnsd,int **inodv,int *ixx,int *icord1);

void preproc2(int nn,int ns,int maxdim,int maxicord1,int *nnsd,int **inodv,int *ixx,int *icord1,int **icord2,int *ispind1,int *inz1);

void preproc3(int nn,int ns,int maxdim,int maxicord1,int *nnsd,int **inodv,int *ixx,int *icord1,int **icord2,int *ispind1,int *inz1,int *ispars1);

void process(int nn,int ns,int maxdim,int ivdim,int ic,int *nnsd,int **inodv,double xkmatsamp[maxdim*ivdim][maxdim*ivdim],int *ispind1,int *inz1,int *ispars1,int *irowind1,double *xktotal1);

void postproc(int nn,int ivdim,int *inz1,int *ispind1,int *nnz,int *icolptr1,int *irowind1,double *xktotal1);

