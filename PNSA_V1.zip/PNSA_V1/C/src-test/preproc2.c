#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include <omp.h>
void preproc2(int nn,int ns,int maxdim,int maxicord1,int *nnsd,int **inodv,int *ixx,int *icord1,int **icord2,int *ispind1,int *inz1){
int maxvalixx,i,iq2,ie,ij,j,numzero2,je,ielement,ii,iii;
for(i = 0; i < nn; i++)for(j = 0; j < maxicord1; j++)icord2[i][j]=0;
maxvalixx=ixx[0];for ( i=0; i<ns;i++)if(ixx[i] > maxvalixx)maxvalixx=ixx[i];
int inter1[maxvalixx];
int *iq1=(int *)calloc(nn, sizeof(int)); 
//********************************************************************start1
for(ie = 0; ie < ns; ie++)
        for(ij = 0; ij < nnsd[ie]; ij++){  
        iq1[inodv[ie][ij]-1]=iq1[inodv[ie][ij]-1]+1;
        icord2[inodv[ie][ij]-1][iq1[inodv[ie][ij]-1]-1]=ie;
        }
#pragma omp parallel for default(shared) private(i,iii,ie,je,j,iq2,ii,numzero2,ielement,inter1) 
for(i = 1; i < nn+1; i++){
	for(iii = 0; iii < maxvalixx; iii++)inter1[iii]=0;
	iq2=0;
	for (ie = 0; ie < icord1[i-1]; ie++){
	ielement=icord2[i-1][ie];
		for (je = 0; je < nnsd[ielement]; je++){
		iq2=iq2+1;
		inter1[iq2-1]=inodv[ielement][je];
		}
	}
	numzero2=0;
	for (j = 0; j < ixx[i-1]; j++){
		for (ii = j+1; ii < ixx[i-1]; ii++){	
			if (inter1[j] == inter1[ii]){
			numzero2=numzero2+1;
			break;
			}
		}
	}
ispind1[i-1]=ixx[i-1]-numzero2;
}
int iq3=0;
for(i = 1; i < nn+1; i++){
iq3=iq3+ispind1[i-1];
inz1[i-1]=iq3;
}
//free(inter1);
free(iq1);
}

