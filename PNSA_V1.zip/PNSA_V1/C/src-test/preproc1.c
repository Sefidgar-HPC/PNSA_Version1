#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include <omp.h>
void preproc1(int nn,int ns,int ivdim,int maxdim,int *nnsd,int **inodv,int *ixx,int *icord1){
int i,ij,ie;
for(i = 0; i < nn; i++)ixx[i]=0;
for(i = 0; i < nn; i++)icord1[i]=0;
#pragma omp parallel for default(shared) private(ie,ij) reduction(+:icord1[:nn])reduction(+:ixx[:nn])
for (ie = 0; ie < ns; ie++)
	for (ij = 0; ij <nnsd[ie]; ij++){
	icord1[inodv[ie][ij]-1]=icord1[inodv[ie][ij]-1]+1;
	ixx[inodv[ie][ij]-1]=ixx[inodv[ie][ij]-1]+nnsd[ie];
	}
}
