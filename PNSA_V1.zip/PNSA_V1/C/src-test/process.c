#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
void process(int nn,int ns,int maxdim,int ivdim,int ic,int *nnsd,int **inodv,double xkmatsamp[maxdim*ivdim][maxdim*ivdim],int *ispind1,int *inz1,int *ispars1,int *irowind1,double *xktotal1){
int i,j,i1,ii,jj,iloc;
for ( i = 0; i < nnsd[ic]; i++){
	for ( j = 0; j < nnsd[ic]; j++){
		for ( i1 = 0; i1 < ispind1[inodv[ic][i]-1]; i1++)
		if (ispars1[inz1[inodv[ic][i]-1]-ispind1[inodv[ic][i]-1]+i1] == inodv[ic][j])break;
		for ( ii = 0; ii < ivdim; ii++){
			for ( jj = 0; jj < ivdim; jj++){
iloc=(inz1[inodv[ic][i]-1]-ispind1[inodv[ic][i]-1])*ivdim*ivdim+ii*ispind1[inodv[ic][i]-1]*ivdim+i1*ivdim+jj;
			irowind1[iloc]=ivdim*inodv[ic][j]-ivdim+jj;
			xktotal1[iloc]=xktotal1[iloc]+xkmatsamp[i*ivdim+ii][j*ivdim+jj];
			}
		}
	}
}
}
