/*
PNSA for C, OpenMP interface

Please send your vluable feedbcks to us:
Seyed Mohammad Hassan Sefidgar (Master of Strutural Engineering): hasan.mamad1370.mh@gmail.com
Ali Rahmani Firoozjaee (PhD of Computational Mechanics): rahmani@nit.ac.ir

!INPUTS:
!nn: Number of total nodes.
!ns: Number of total elements.
!ivdim: Number of unknowns per node (DOF).
!nnsd: How many nodes exist on each support domain (elements).
!inodv: Indexes of nodes exist on each support domain (elements).
!xkmatsamp: Local stiffness matrix for each support domain (elements).

!OUTPUTS:
!nnz: Number of non-zero.
!ixx: Number of nodes are connected to each node via shared elements(collision exist).
!icord1: Stores how many support domains are connected to each node.
!icord2: Indexes of support domains that each node exist there.
!ispind1: Number of nodes existing on each support domain after removing collisions.
!inz1: Cumulative sum of ispind1.
!ispars1: Row-index for each node (final row-index if DOF equals one).
!irowind1: Final row-index vector consist of real DOFs (sparse pattern of each DOF).
!xktotal1: Values of final stiffness matrix corresponding to irowind1 consist of real DOFs.
!icolptr1: Final column pointer vector consist of real DOFs (sparse pattern of each DOF).*/
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include <omp.h>
#include "PNSA.h"
int main(){
/*Allocating initial variables*/
int const nn=6;
int const ns=4;
int const ivdim=2;
int maxdim, maxicord1, ic , nnz;
int *icolptr1= 	(int *)calloc(nn*ivdim+1, sizeof(int)); 
int *ixx     = 	(int *)calloc(nn, sizeof(int)); 
int *icord1  = 	(int *)calloc(nn, sizeof(int)); 
int *inz1    = 	(int *)calloc(nn, sizeof(int)); 
int *ispind1 = 	(int *)calloc(nn, sizeof(int)); 
int *nnsd    = 	(int *)calloc(ns, sizeof(int)); 
int i,j,i2,j2;
nnsd[0]=2;
nnsd[1]=4;
nnsd[2]=3;
nnsd[3]=1;

       /*Finding maximum of nnsd[ns]*/
maxdim=nnsd[0];for ( i = 0; i < ns; i++)if(nnsd[i] > maxdim) maxdim=nnsd[i];

       /*Allocating inodv[ns][maxdim]*/
int **inodv=(int**) malloc(ns*sizeof(int*));for ( i=0;i<ns;i++) inodv[i]=(int*)malloc(maxdim*sizeof(int));
for ( i = 0; i < ns; i++)for ( j = 0; j < maxdim; j++)inodv[i][j]=0;
inodv[0][0]=2;
inodv[0][1]=4;
inodv[1][0]=2;
inodv[1][1]=5;
inodv[1][2]=6;
inodv[1][3]=3;
inodv[2][0]=5;
inodv[2][1]=1;
inodv[2][2]=2;
inodv[3][0]=1;

       /*Allocating xkmatsamp[maxdim*ivdim][maxdim*ivdim]*/
double xkmatsamp[maxdim*ivdim][maxdim*ivdim];
for ( i2 = 0; i2 < maxdim*ivdim; i2++)for ( j2 = 0; j2 < maxdim*ivdim; j2++)xkmatsamp[i2][j2]=0;

       /*finding ixx,icord1*/
preproc1(nn,ns,ivdim,maxdim,nnsd,inodv,ixx,icord1);

       /*Finding maxicord1*/
maxicord1=icord1[0];for ( i=0; i<nn;i++)if(icord1[i] > maxicord1)maxicord1=icord1[i];

       /*Allocating icord2[ns][maxicord1]*/
int **icord2=(int**) malloc(nn*sizeof(int*));for ( i=0;i<nn;i++)icord2[i]=(int*)malloc(maxicord1*sizeof(int));
for ( i = 0; i < nn; i++)for ( j = 0; j < maxicord1; j++)icord2[i][j]=0;

       /*Finding icord2,ispind1,inz1*/
preproc2(nn,ns,maxdim,maxicord1,nnsd,inodv,ixx,icord1,icord2,ispind1,inz1);

       /*Allocating ispars1[inz1[nn-1]],irowind1[inz1[nn-1]*ivdim*ivdim]; xktotal1[inz1[nn-1]*ivdim*ivdim];*/
int *ispars1= 	  (int *)calloc(inz1[nn-1], sizeof(int)); 
int *irowind1= 	  (int *)calloc(inz1[nn-1]*ivdim*ivdim, sizeof(int)); 
double *xktotal1= (double *)calloc(inz1[nn-1]*ivdim*ivdim, sizeof(double)); 
int innz=inz1[nn-1]*ivdim*ivdim;
printf ("innz=%d\n",innz);

       /*Finding ispars1[inz1[nn-1]],irowind1[inz1[nn-1]*ivdim*ivdim]; xktotal1[inz1[nn-1]*ivdim*ivdim];*/
preproc3(nn,ns,maxdim,maxicord1,nnsd,inodv,ixx,icord1,icord2,ispind1,inz1,ispars1);

       /*Mapping all elements of matrces to irowind1,xktotal1*/
#pragma omp parallel for default(shared) private(ic,i2,j2) firstprivate(xkmatsamp) reduction(+:xktotal1[:innz]) \
reduction(max:irowind1[:innz])
for (ic=0 ; ic < ns ; ic++){
	if (ic == 0){
xkmatsamp[0][0]=61;xkmatsamp[0][1]=45;xkmatsamp[0][2]=38;xkmatsamp[0][3]=34;
xkmatsamp[1][0]=54;xkmatsamp[1][1]=47;xkmatsamp[1][2]=43;xkmatsamp[1][3]=40;
xkmatsamp[2][0]=56;xkmatsamp[2][1]=52;xkmatsamp[2][2]=49;xkmatsamp[2][3]=48;
xkmatsamp[3][0]=62;xkmatsamp[3][1]=58;xkmatsamp[3][2]=57;xkmatsamp[3][3]=51;
process( nn, ns, maxdim, ivdim, ic, nnsd, inodv, xkmatsamp, ispind1, inz1, ispars1, irowind1, xktotal1);
	}

	if (ic == 1){ 
xkmatsamp[0][0]=211;xkmatsamp[0][1]=112;xkmatsamp[0][2]=79; xkmatsamp[0][3]=64;
xkmatsamp[1][0]=121;xkmatsamp[1][1]=122;xkmatsamp[1][2]=89; xkmatsamp[1][3]=74;
xkmatsamp[2][0]=231;xkmatsamp[2][1]=132;xkmatsamp[2][2]=99; xkmatsamp[2][3]=84;
xkmatsamp[3][0]=241;xkmatsamp[3][1]=142;xkmatsamp[3][2]=109;xkmatsamp[3][3]=94;
xkmatsamp[4][0]=291;xkmatsamp[4][1]=152;xkmatsamp[4][2]=0;  xkmatsamp[4][3]=104;
xkmatsamp[5][0]=161;xkmatsamp[5][1]=162;xkmatsamp[5][2]=0;  xkmatsamp[5][3]=114;
xkmatsamp[6][0]=271;xkmatsamp[6][1]=172;xkmatsamp[6][2]=139;xkmatsamp[6][3]=124;
xkmatsamp[7][0]=281;xkmatsamp[7][1]=182;xkmatsamp[7][2]=149;xkmatsamp[7][3]=134;

xkmatsamp[0][4]=55; xkmatsamp[0][5]=49; xkmatsamp[0][6]=45; xkmatsamp[0][7]=43;
xkmatsamp[1][4]=65; xkmatsamp[1][5]=59; xkmatsamp[1][6]=55; xkmatsamp[1][7]=53;
xkmatsamp[2][4]=75; xkmatsamp[2][5]=69; xkmatsamp[2][6]=65; xkmatsamp[2][7]=0;
xkmatsamp[3][4]=0;  xkmatsamp[3][5]=79; xkmatsamp[3][6]=77; xkmatsamp[3][7]=73;
xkmatsamp[4][4]=91; xkmatsamp[4][5]=89; xkmatsamp[4][6]=85; xkmatsamp[4][7]=83;
xkmatsamp[5][4]=105;xkmatsamp[5][5]=13; xkmatsamp[5][6]=95; xkmatsamp[5][7]=93;
xkmatsamp[6][4]=115;xkmatsamp[6][5]=109;xkmatsamp[6][6]=15; xkmatsamp[6][7]=103;
xkmatsamp[7][4]=125;xkmatsamp[7][5]=119;xkmatsamp[7][6]=117;xkmatsamp[7][7]=113;
process( nn, ns, maxdim, ivdim, ic, nnsd, inodv, xkmatsamp, ispind1, inz1, ispars1, irowind1, xktotal1);
	}

	if (ic == 2){
xkmatsamp[0][0]=311;xkmatsamp[0][1]=312;xkmatsamp[0][2]=13; 
xkmatsamp[1][0]=101;xkmatsamp[1][1]=172;xkmatsamp[1][2]=193; 
xkmatsamp[2][0]=131;xkmatsamp[2][1]=232;xkmatsamp[2][2]=133; 
xkmatsamp[3][0]=19; xkmatsamp[3][1]=117;xkmatsamp[3][2]=118; 
xkmatsamp[4][0]=181;xkmatsamp[4][1]=112;xkmatsamp[4][2]=519; 
xkmatsamp[5][0]=111;xkmatsamp[5][1]=11; xkmatsamp[5][2]=113; 

xkmatsamp[0][3]=319;xkmatsamp[0][4]=315;xkmatsamp[0][5]=316; 
xkmatsamp[1][3]=174;xkmatsamp[1][4]=105;xkmatsamp[1][5]=176; 
xkmatsamp[2][3]=134;xkmatsamp[2][4]=195;xkmatsamp[2][5]=136; 
xkmatsamp[3][3]=119;xkmatsamp[3][4]=120;xkmatsamp[3][5]=121; 
xkmatsamp[4][3]=114;xkmatsamp[4][4]=15 ;xkmatsamp[4][5]=17; 
xkmatsamp[5][3]=14; xkmatsamp[5][4]=0  ;xkmatsamp[5][5]=116;
process( nn, ns, maxdim, ivdim, ic, nnsd, inodv, xkmatsamp, ispind1, inz1, ispars1, irowind1, xktotal1);
	}

	if (ic == 3){ 
xkmatsamp[0][0]=311;xkmatsamp[0][1]=112;
xkmatsamp[1][0]=221;xkmatsamp[1][1]=522;
process( nn, ns, maxdim, ivdim, ic, nnsd, inodv, xkmatsamp, ispind1, inz1, ispars1, irowind1, xktotal1);
	}
}

 /*Ramoveing possible intrinsic zero on each matrix finding icolptr1 finalizing nnz,icolptr1,irowind1,xktotal1*/
postproc(nn,ivdim,inz1,ispind1,&nnz,icolptr1,irowind1,xktotal1);

      /*Final reaults*/
printf("nnz=%d\n",nnz);//Number of None Zeros
for( i=0;i<nn*ivdim+1;i++)printf("%d\t%d\n",i,icolptr1[i]);
printf ("non-zero	irowind		xktotal1\n");
for( i=0;i<nnz;i++) printf("%d\t%d\t%lf\n",i,irowind1[i],xktotal1[i]);
printf ("Test example for OpenMP version of PNSA is successfully compiled and run in C interface\n");
      /*Freeing heap to avoid memory leak*/
free(icolptr1);
free(nnsd);
free(ixx);
free(icord1);
free(inz1);
free(ispind1);
for ( i = 0; i < ns; i++)free(inodv[i]);
free(inodv);
for ( i = 0; i < nn; i++)free(icord2[i]);
free(icord2);
free(ispars1);
free(irowind1);
free(xktotal1);
return 0;
}
