#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include <omp.h>
void preproc3(int nn,int ns,int maxdim,int maxicord1,int *nnsd,int **inodv,int *ixx,int *icord1,int **icord2,int *ispind1,int *inz1,int *ispars1){
int i,maxvalixx,ielement,iq1,ie,je,ii,j,iq2;
maxvalixx=ixx[0];for (i=0;i<nn;i++)if(ixx[i]>maxvalixx) maxvalixx=ixx[i];
int inter2 [maxvalixx][2];
for (i=0; i<maxvalixx; i++) for (j=0; j<2; j++)inter2[i][j]=0;
//int **inter2 = (int **)malloc(maxvalixx * sizeof(int *)); 
//for (i=0; i<maxvalixx; i++) inter2[i] = (int *)malloc(2 * sizeof(int)); 
#pragma omp parallel for default(shared) private(i,iq1,ie,je,j,ii,ielement,iq2) firstprivate(inter2)
for (i = 1; i < nn+1; i++){
	iq1=0;
	for (ie = 0; ie < icord1[i-1]; ie++){
	ielement=icord2[i-1][ie];
		for (je = 0; je < nnsd[ielement]; je++){
		iq1=iq1+1;
		inter2[iq1-1][0]=inodv[ielement][je];
		inter2[iq1-1][1]=iq1;
		}
	}
	for (j = 0; j < ixx[i-1]; j++){
		for (ii = j+1; ii < ixx[i-1]; ii++){	
			if (inter2[j][0] == inter2[ii][0]){
			inter2[ii][1]=0;
			break;
			}
		}
	}
	iq2=-1;
	for (j = 0; j < ixx[i-1]; j++){
		if (inter2[j][1] != 0){
		iq2=iq2+1;
		ispars1[inz1[i-1]-ispind1[i-1]+iq2]=inter2[j][0];

		}
	}

}
}
