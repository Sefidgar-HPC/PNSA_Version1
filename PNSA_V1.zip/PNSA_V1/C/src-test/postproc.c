#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
void postproc(int nn,int ivdim,int *inz1,int *ispind1,int *nnz,int *icolptr1,int *irowind1,double *xktotal1){
int i,j,ii,ii1;
*nnz=0;
for (i=0;i<nn;i++){
	for (j=0;j<ivdim;j++){
	icolptr1[i*ivdim+j]=*nnz+1;
		for (ii=ispind1[i]*ivdim*j;ii<ispind1[i]*ivdim*(j+1);ii++){
		ii1=(inz1[i]-ispind1[i])*ivdim*ivdim+ii;
			if (xktotal1[ii1] != 0){
      			*nnz=*nnz+1;
     			irowind1[*nnz-1]=irowind1[ii1];
     			xktotal1[*nnz-1]=xktotal1[ii1];
			}
		}
	}
}
icolptr1[nn*ivdim]=*nnz+1;
}
