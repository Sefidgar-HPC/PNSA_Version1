In this folder inputs and PNSA parameters for the first case_study (Meshless Case-Study1) is presesented according to the tutorial.
