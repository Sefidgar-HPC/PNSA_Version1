In this folder inputs and PNSA parameters for the third case_study (FEM) is presesented according to the tutorial.
