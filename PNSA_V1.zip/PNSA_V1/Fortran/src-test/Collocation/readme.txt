In this folder inputs and PNSA parameters for the second case_study (Meshless Case-Study2) is presesented according to the tutorial.
