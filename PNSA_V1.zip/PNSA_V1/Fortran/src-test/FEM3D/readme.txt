In this folder inputs and PNSA parameters for the fourth case_study (truss3D) is presesented according to the tutorial.
